from flask import Flask, render_template, request
import pandas as pd
import pickle as pk

app = Flask(__name__)

# Load model and scaler
model = pk.load(open('model.pkl','rb'))
scaler = pk.load(open('scaler.pkl','rb'))

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    # Get form data
    no_of_dep = int(request.form['no_of_dependents'])
    grad = request.form['education']
    self_emp = request.form['self_employed']
    Annual_Income = float(request.form['income_annum'])
    Loan_Amount = float(request.form['loan_amount'])
    Loan_Dur = float(request.form['loan_term'])
    Cibil = float(request.form['cibil_score'])
    Assets = float(request.form['Assets'])

    # Process education and employment status
    grad_s = 0 if grad == 'Graduated' else 1
    emp_s = 1 if self_emp == 'Yes' else 0

    # Create prediction DataFrame
    pred_data = pd.DataFrame([[no_of_dep, grad_s, emp_s, Annual_Income, 
                             Loan_Amount, Loan_Dur, Cibil, Assets]],
                           columns=['no_of_dependents', 'education', 'self_employed', 
                                    'income_annum', 'loan_amount', 'loan_term', 
                                    'cibil_score', 'Assets'])
    
    # Scale and predict
    pred_data_scaled = scaler.transform(pred_data)
    prediction = model.predict(pred_data_scaled)[0]
    
    # Determine result and reason
    if prediction == 1:
        result = "✅ Approved"
        reason = ""
    else:
        result = "❌ Rejected"
        rejection_reasons = []
        
        # Add your rejection logic here
        if Annual_Income < 250000:
            rejection_reasons.append("Applicant income is too low")
        if Loan_Amount > 5000000:
            rejection_reasons.append("Requested loan amount is high")
        if Loan_Dur < 5:
            rejection_reasons.append("Short repayment term")
        if no_of_dep > 3:
            rejection_reasons.append("Too many dependents")
            
        reason = ", ".join(rejection_reasons) or "Does not meet lending criteria"

    return render_template('result.html', prediction=result, reason=reason)

if __name__ == '__main__':
    app.run(debug=True)